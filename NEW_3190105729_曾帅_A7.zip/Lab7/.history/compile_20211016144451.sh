g++ SolarSystem.cpp -o SolarSystem -lGL -lGLU -lglut
./SolarSystem
