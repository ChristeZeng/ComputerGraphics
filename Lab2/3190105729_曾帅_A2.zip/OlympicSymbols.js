const red    = [220.0/255.0, 47.0/225.0, 31.0/225.0];
const blue   = [0, 107.0/225.0, 176.0/225.0];
const yellow = [239.0/255.0, 169.0/225.0, 13.0/225.0];
const black  = [29.0/255.0, 24.0/225.0, 21.0/225.0];
const green  = [5.0/255.0, 147.0/225.0, 65.0/225.0];

function main()
{
    //获取canvas元素
    var canvas = document.getElementById('gl-canvas');
    //获取webgl上下文
    var gl = canvas.getContext("webgl");
    if(!gl)
    {
        alert("WebGL is not supported");
        return;
    }

    //顶点着色器
    var vsSource = `
        attribute vec4 position;
        void main()
        {
            gl_Position = position;
        }
    `;
    //片段着色器
    var fsSource = `
        precision mediump float;
        uniform vec3 color;
        void main()
        {
            gl_FragColor = vec4(color, 1.0);
        }
    `;
    
    //初始化着色器
    var shaderProgram = initShaderProgram(gl, vsSource, fsSource);
    if(!shaderProgram)
    {
        alert("Error: initshader");
        return;
    }

    //获取变量
    gl.useProgram(shaderProgram);
    var position = gl.getAttribLocation(shaderProgram, 'position');
    var color = gl.getUniformLocation(shaderProgram, 'color');
    
    //绘制奥运五环
    draw();

    function draw()
    {
        //将背景重置为白色
        gl.clearColor(1.0, 1.0, 1.0, 1.0);  
        //清除canvas
        gl.clear(gl.COLOR_BUFFER_BIT);
        
        //画左上蓝色完整圆环
        drawRing(-0.26, 0.0, 0, 100, blue);
        //画上中黑色完整圆环
        drawRing(0, 0, 0, 100, black);
        //画右上红色完整圆环
        drawRing(0.26, 0, 0, 100, red);
        //画左下黄色完整圆环
        drawRing(-0.13, -0.11, 0, 100, yellow);
        //画右下绿色完整圆环
        drawRing(0.13, -0.11, 0, 100, green);
        //重画黄蓝环连接处
        drawRing(-0.26, 0.0, 20, 30, blue);
        //重画黄黑环连接处
        drawRing(0, 0, 50, 60, black);
        //重画绿黑环连接处
        drawRing(0, 0, 20, 30, black);
        //重画红绿环连接处
        drawRing(0.26, 0, 50, 60, red);   
    }

    //按角度画圆环
    function drawRing(xoff, yoff, begin, end, colors)
    {
        //设置画笔为黑色
        gl.uniform3f(color, colors[0], colors[1], colors[2]);
        
        //计算顶点坐标位置
        var N = 100;
        var vertices = [];
        var r_inner = 0.1;
        var r_outter = 0.12;

        for (var i = begin; i <= end; i++) 
        {
            var theta = i * 2 * Math.PI / N;
            var x_inner = xoff + r_inner * Math.sin(theta);
            var y_inner = yoff + r_inner * Math.cos(theta);
            var x_outter = xoff + r_outter * Math.sin(theta);
            var y_outter = yoff + r_outter * Math.cos(theta);
            vertices.push(x_inner, y_inner);
            vertices.push(x_outter, y_outter);
        }
        //创建缓冲区对象
        var positionBuffer = gl.createBuffer();
        //将缓冲区对象绑定到目标
        gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
        //向缓冲区对象写入数据
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
        //从当前绑定的缓冲区中读取顶点数据。
        gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);
        //激活每一个属性
        gl.enableVertexAttribArray(position);
        //利用TRIANGLE_STRIP参数三角拟合
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, vertices.length / 2);
    }
}


//初始化着色器
function initShaderProgram(gl, vsSource, fsSource)
{
    
    const vertexShader = loadShader(gl, gl.VERTEX_SHADER, vsSource);
    const fragmentShader = loadShader(gl, gl.FRAGMENT_SHADER, fsSource);

    //创建着色器程序
    const shaderProgram = gl.createProgram();
    gl.attachShader(shaderProgram, vertexShader);
    gl.attachShader(shaderProgram, fragmentShader);
    gl.linkProgram(shaderProgram);

    if(!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS))
    {
        alert("Error");
        return null;
    }

    return shaderProgram;
}

function loadShader(gl, type, source)
{
    const shader = gl.createShader(type);

    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if(!gl.getShaderParameter(shader, gl.COMPILE_STATUS))
    {
        alert("Error: Compile");
        gl.deleteShader(shader);
        return null;
    }
    return shader;
}