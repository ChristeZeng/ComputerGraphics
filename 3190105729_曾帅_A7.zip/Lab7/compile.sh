g++ main.cpp Car.h -o main -lGL -lGLU -lglut
./main
