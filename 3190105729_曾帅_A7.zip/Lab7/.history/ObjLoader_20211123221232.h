#include <GL/glut.h>
#include <iostream>
#include <cmath>
