g++ main.cpp ObjLoader.h -o main -lGL -lGLU -lglut
./main
